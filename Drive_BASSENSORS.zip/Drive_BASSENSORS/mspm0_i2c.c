/*
 * Copyright (c) 2025, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "ti_msp_dl_config.h"
#include "mspm0_i2c.h"

/* I2C Controller */
I2CDev_t gI2CCtrl = {
    0,0,NULL,0,0,NULL,I2C_STATUS_IDLE
};

void I2C_StartWrite(I2C_Regs *i2c, uint8_t addr, uint8_t *data, uint16_t len)
{
    if(gI2CCtrl.status != I2C_STATUS_IDLE) {
        return;
    }

    gI2CCtrl.txCnt = 0;
    gI2CCtrl.txBuf = data;
    gI2CCtrl.txLen = len;
    gI2CCtrl.status = I2C_STATUS_TX_STARTED;

    /* Fill FIFO with data. */
    gI2CCtrl.txCnt = DL_I2C_fillControllerTXFIFO(i2c, &gI2CCtrl.txBuf[0], gI2CCtrl.txLen);
    /* Send the packet to the controller.
     * This function will send Start + Stop automatically. */
    DL_I2C_startControllerTransfer(i2c, addr, DL_I2C_CONTROLLER_DIRECTION_TX, gI2CCtrl.txLen);
    DL_I2C_clearInterruptStatus(i2c, DL_I2C_INTERRUPT_CONTROLLER_TXFIFO_TRIGGER);
    DL_I2C_enableInterrupt(i2c, DL_I2C_INTERRUPT_CONTROLLER_TXFIFO_TRIGGER);

    return;
}

void I2C_StartRead(I2C_Regs *i2c, uint8_t addr, uint8_t *data, uint16_t len)
{
    if(gI2CCtrl.status != I2C_STATUS_IDLE) {
        return;
    }

    gI2CCtrl.rxCnt = 0;
    gI2CCtrl.rxBuf = data;
    gI2CCtrl.rxLen = len;
    gI2CCtrl.status = I2C_STATUS_RX_STARTED;

    /* Send a read request to Target */
    DL_I2C_startControllerTransfer(i2c, addr, DL_I2C_CONTROLLER_DIRECTION_RX, gI2CCtrl.rxLen);

    return;
}

void I2C_RepeatStart_WrRd(  I2C_Regs *i2c, uint8_t addr,
                            uint8_t *txData, uint16_t txLen,
                            uint8_t *rxData, uint16_t rxLen)
{
    if(gI2CCtrl.status != I2C_STATUS_IDLE) {
        return;
    }

    gI2CCtrl.txCnt = 0;
    gI2CCtrl.txBuf = txData;
    gI2CCtrl.txLen = txLen;
    gI2CCtrl.rxCnt = 0;
    gI2CCtrl.rxBuf = rxData;
    gI2CCtrl.rxLen = rxLen;
    gI2CCtrl.status = I2C_STATUS_TX_STARTED;

    //TODO: Add repeat start write read fucntion here.
    
    gI2CCtrl.status = I2C_STATUS_RX_STARTED;
}

I2CStatus_t I2C_GetStatus(void)
{
    return gI2CCtrl.status;
}


void I2C_INST_IRQHandler(void)
{
    switch (DL_I2C_getPendingInterrupt(I2C_INST)) {
        case DL_I2C_IIDX_CONTROLLER_RX_DONE:
            gI2CCtrl.status = I2C_STATUS_RX_COMPLETE;   
            break;
        case DL_I2C_IIDX_CONTROLLER_TX_DONE:
            DL_I2C_disableInterrupt(I2C_INST, DL_I2C_INTERRUPT_CONTROLLER_TXFIFO_TRIGGER);
            gI2CCtrl.status = I2C_STATUS_TX_COMPLETE;
            break;
        case DL_I2C_IIDX_CONTROLLER_RXFIFO_TRIGGER:
            gI2CCtrl.status = I2C_STATUS_RX_INPROGRESS;
            /* Receive all bytes from target */
            while (DL_I2C_isControllerRXFIFOEmpty(I2C_INST) != true) {
                if (gI2CCtrl.rxCnt < gI2CCtrl.rxLen) {
                    gI2CCtrl.rxBuf[gI2CCtrl.rxCnt++] = DL_I2C_receiveControllerData(I2C_INST);
                } else {
                    /* Ignore and remove from FIFO if the buffer is full */
                    DL_I2C_receiveControllerData(I2C_INST);
                }
            }
            break;
        case DL_I2C_IIDX_CONTROLLER_TXFIFO_TRIGGER:
            gI2CCtrl.status = I2C_STATUS_TX_INPROGRESS;
            /* Fill TX FIFO with next bytes to send */
            if (gI2CCtrl.txCnt < gI2CCtrl.txLen) {
                gI2CCtrl.txCnt += DL_I2C_fillControllerTXFIFO(I2C_INST,
                    &gI2CCtrl.txBuf[gI2CCtrl.txCnt],
                    gI2CCtrl.txLen - gI2CCtrl.txCnt);
            }
            break;
            /* Not used for this example */
        case DL_I2C_IIDX_CONTROLLER_ARBITRATION_LOST:
        case DL_I2C_IIDX_CONTROLLER_NACK:
            if ((gI2CCtrl.status == I2C_STATUS_RX_STARTED) ||
                (gI2CCtrl.status == I2C_STATUS_TX_STARTED)) {
                /* NACK interrupt if I2C Target is disconnected */
                gI2CCtrl.status = I2C_STATUS_ERROR;
            }
        case DL_I2C_IIDX_CONTROLLER_STOP:
            gI2CCtrl.status = I2C_STATUS_IDLE;
            break;
        case DL_I2C_IIDX_CONTROLLER_RXFIFO_FULL:
        case DL_I2C_IIDX_CONTROLLER_TXFIFO_EMPTY:
        case DL_I2C_IIDX_CONTROLLER_START:
        case DL_I2C_IIDX_CONTROLLER_EVENT1_DMA_DONE:
        case DL_I2C_IIDX_CONTROLLER_EVENT2_DMA_DONE:
        default:
            break;
    }
}
